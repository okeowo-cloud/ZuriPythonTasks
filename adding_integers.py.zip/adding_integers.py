a = int(input("pls input a number: "))
b = int(input("pls input another number: "))
result = a + b
print("The result is: ", result)
