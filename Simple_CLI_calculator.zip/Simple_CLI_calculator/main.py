def simple_calculator(number1, number2):
    operation = input("please choose one operation '+', '-', '*', '/': ")
    if operation == '+':
        return number1 + number2
    elif operation == '-':
        return number1 - number2
    elif operation == '*':
        return number1 * number2
    elif operation == '/':
        if number2 == 0:
            print("Division by zero is not possible")
        else:
            return number1 / number2
    else:
        print("operation not found")


a = int(input("please enter the first number: "))
b = int(input("please enter the second number: "))
result = simple_calculator(a, b)
print(result)
